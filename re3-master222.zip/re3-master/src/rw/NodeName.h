#pragma once

bool NodeNamePluginAttach(void);
char *GetFrameNodeName(RwFrame *frame);
