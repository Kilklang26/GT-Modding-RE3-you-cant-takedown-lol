#ifndef EVENTS_H
#define EVENTS_H

#include <rwcore.h>
#include "skeleton.h"

#endif /* EVENTS_H */
