#pragma once

class CRemote
{
public:
	static void GivePlayerRemoteControlledCar(float, float, float, float, uint16);
	static void TakeRemoteControlledCarFromPlayer(void);
};
