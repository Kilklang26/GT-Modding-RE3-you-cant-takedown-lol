#pragma once

// Pretty sure this class is not used by the game
class CTimeStep
{
public:
	static float ms_fTimeScale;
	static float ms_fFramesPerUpdate;
	static float ms_fTimeStep;
};
