#pragma once

RwImage *RtBMPImageWrite(RwImage * image, const RwChar * imageName);
RwImage *RtBMPImageRead(const RwChar * imageName);
